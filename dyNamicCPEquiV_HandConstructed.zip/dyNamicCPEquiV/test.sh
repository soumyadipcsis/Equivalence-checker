#!/bin/bash
 ./pres example/MODN/MODN_ORG.PRES example/MODN/MODN_TRANS.PRES > example/MODN/VerificationReport.txt

./pres example/DCT/DCT.org example/DCT/DCT.schd > example/DCT/VerificationReport.txt

./pres example/GCD/GCD_ORG.PRES example/GCD/GCD_TRANS.PRES > example/GCD/VerificationReport.txt

./pres example/LCM/LCM_ORG.PRES example/LCM/LCM_TRANS.PRES > example/LCM/VerificationReport.txt

./pres example/PERFECT/PERFECT_ORG.PRES example/PERFECT/PERFECT_TRANS.PRES > example/PERFECT/VerificationReport.txt

./pres example/PRIMEFAC/PRIMEFAC_ORG.PRES example/PRIMEFAC/PRIMEFAC_TRANS.PRES > example/PRIMEFAC/VerificationReport.txt

./pres example/SOD/SOD_ORG.PRES example/SOD/SOD_TRANS.PRES > example/SOD/VerificationReport.txt

./pres example/TLC/testcase/TLC_ORG.PRES example/TLC/testcase/TLC_TRANS.PRES > example/TLC/VerificationReport.txt

./pres example/LRU/LRU_ORG.PRES example/LRU/LRU_TRANS.PRES > example/LRU/VerificationReport.txt

./pres example/BCM/BCM_ORG.PRES example/BCM/BCM_TRANS.PRES > example/BCM/VerificationReport.txt
