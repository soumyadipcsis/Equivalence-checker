
main()
{
	int i,j,k;
	for(;i<j+k;)
	{
	}
}



	
