int across()
{
	int a[100], b[100], c[100]; //inputs
	int e[100]; //output
	int t1[100], t2[100]; //temporary arrays
	int i, n;
	
	//loop fission
	for(i = 2; i <= 50; i=i+1)
	{
		t2[i] = a[i-1] + c[i];      // S2
	}
	for(i = 2; i <= 50; i=i+1)
	{
		t1[i] = (b[i]+ c[i-1]) * 2; // S1 - order of execution reversed
	}
	for(i = 2; i <= 50; i=i+1)
	{
		e[i] = t2[i-2] + t1[i];     //commutative
	}

	return 0;
}
