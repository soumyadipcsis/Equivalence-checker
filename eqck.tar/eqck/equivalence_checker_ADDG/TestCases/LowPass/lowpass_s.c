#define	N	100
 
void lowpass()
{
   int i, j;
   int a[200][200];
   int a1[200][200];
 
   for (i=1; i<100; i+=1) {
     for (j=1; j<100; j+=1) {
        a1[i][j] = 9 * a[i-1][j-1] + a[i-1][j] + 2 * a[i-1][j+1] +
                  3 * a[i][j-1]   + 4 * a[i][j]   + 5 * a[i][j+1]   +
                  6 * a[i+1][j-1] + 7 * a[i+1][j] + 8 * a[i+1][j+1];
     }
   }
 }
 

