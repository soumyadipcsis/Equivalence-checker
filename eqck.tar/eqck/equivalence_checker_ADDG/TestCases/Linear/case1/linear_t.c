void linear()
{
    long argument , k , l , i, kb5i;
    long sa[101], sb[101], b5[101], stb5[1];

     for ( k=0 ; k<101 ; k+=1 ){
        for ( l=1 ; l<=1000 ; l+=1 ){ //loop interchange: k and l
            b5[k] = sa[k] + stb5[0]*sb[k]; 
        }
        for ( i=100 ; i>=0 ; i-=1 ) { //loop reversal: i
            b5[i] = sa[i] + stb5[0]*sb[i];
        }
    }
}
