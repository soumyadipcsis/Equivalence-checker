#define	N	100


void laplace()
{
  int i, j;
  int image1[N][N], image2[N][N], temp1[N][N], temp2[N][N];

  for (i=1; i<N; i+=1) {
    for (j=1; j<N; j+=1) {
      temp1[i][j] = image1[i-1][j-1] - 2 * image1[i][j-1] + image1[i+1][j-1] - 2 * image1[i-1][j] + 4 * image1[i][j];
                     
    }
  }

 for (i=1; i<N; i+=1) {
    for (j=1; j<N; j+=1) {
      temp2[i][j] = image1[i-1][j+1] - 2 * image1[i+1][j] - 2 * image1[i][j+1] + image1[i+1][j+1];
    }
  }

 for (i=1; i<N; i+=1) {
    for (j=1; j<N; j+=1) {
      image2[i][j] = temp1[i][j] + temp2[i][j];
    }
  }
}

