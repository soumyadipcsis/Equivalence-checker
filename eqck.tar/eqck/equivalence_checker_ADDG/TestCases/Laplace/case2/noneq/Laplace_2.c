#define	N	100


void laplace()
{
  int i, j;
  int image1[N][N], image2[N][N];

  for (i=1; i<N; i+=1) {
    for (j=1; j<N; j+=2) {
      image2[i][j] = image1[i-1][j-1] - 2 * image1[i][j-1] - 2 * image1[i+1][j] + image1[i+1][j-1] - 2 * image1[i-1][j] + 4 * image1[i][j] + 
                     + image1[i-1][j+1] - 2 * image1[i][j+1] + image1[i+1][j+1];

      image2[i][j+1] = image1[i-1][j] - 2 * image1[i][j] + image1[i+1][j] + 2 * image1[i-1][j+1] + 4 * image1[i][j+1]  //Orig - 2 * image1[i-1][j+1]
                     - 2 * image1[i+1][j+1] + image1[i-1][j+2] - 2 * image1[i][j+2] + image1[i+1][j+2];
    }
  }
}

