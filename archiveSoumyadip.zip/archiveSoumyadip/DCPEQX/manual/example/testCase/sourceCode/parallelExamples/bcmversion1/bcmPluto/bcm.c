#include <stdio.h>

int main()
{ 

 int a,b,c,d,e,f,g,h,i,j,k,l,m;

#pragma scop
  a=b+c;
  d=e+f;
  g=a+d;
  h=i+j;
  k=l+m;
  o=h+k;
#pragma endscop
}
