int c1 = 0, c2 = 0, turn = 1 ; // shared data
/* Process 1 */
while(1){
/* non-critical section */
c1 = 1 ;
while(c2)
if(turn == 2) {
c1 = 0 ;
while(turn == 2) ; // Busy wait
c1 = 1 ;
}
/* critical section */
turn = 2 ;
c1 = 0 ;
/* non-critical section */
}


/* Process 2 
while(1){
/* non-critical section 

c2 = 1 ;
while(c1)
if(turn == 1) {
c2 = 0 ;
while(turn == 1) ; // Busy wait
c2 = 1 ;
}
/* critical section */
turn = 1 ;
c2 = 0 ;
/* non-critical section 
}*/
