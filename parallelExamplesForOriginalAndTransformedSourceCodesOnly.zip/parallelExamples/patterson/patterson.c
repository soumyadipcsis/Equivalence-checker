int c1 = 0, c2 = 0, turn ; // Shared data
/* Process 1 */
while(1){
/* non-CS */
c1 = 1 ;
turn = 1 ;
while(c2 && turn == 1) ;
/* Critical section */
c1 = 0 ;
/* non-CS */
}


/* Process 2 
while(1){
/* non-CS 
c2 = 1 ;
turn = 2 ;
while(c1 && turn == 2) ;
/* Critical section */
c2 = 0 ;
/* non-CS 
}*/
