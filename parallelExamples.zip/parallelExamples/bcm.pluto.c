#include <stdio.h>

int main()
{ 

 int a,b,c,d,e,f,x,h1;


# CLooG code 

  a=b+c;
  g=e+f;

\PAR

  c=d+e;
  x=e+f;

# CLooG code
}
