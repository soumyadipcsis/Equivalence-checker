main()
{
 int i0,i7,i1,i2,i3,i4,i5,i6; 
 int a0,a7,b1,a2,a3,a4,b5,a6,b0,d2,d3,c5,d9,c10;
 int b13;

 a0=i0+i7;
 a7=i0-i7;
 b1=i1+i2;
 a2=i1-i2;
 a3=i3+i4;
 a4=i3-i4;
 b5=i5+i6;
 a6=i5-i6;
 b0=a0+a4;
 d2=a2+a6;
 d3=a3+a7;
 c5=b5*678; 
 d9=b2+d3;
 c10=c5-d2;
 b13=d9+c10;
}
