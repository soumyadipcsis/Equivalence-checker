#include <stdio.h>

void main () {
    int a, b, c, d;
    scanf ("%d", &a);
    if (a < 10) {
        scanf ("%d", &b);
        if (b < 20) {
            b++;
        }
        else {
            b--;
        }
        scanf ("%d", &c);
        if (c < 30) {
            c++;
        } 
        else {
            c--;
        }
        scanf ("%d", &d);
        if (d < 40) {
            d++;
        }
        else {
            d--;
        }
        a++;
    }
    else {
        a--;
    }
    printf ("%d", a);
}