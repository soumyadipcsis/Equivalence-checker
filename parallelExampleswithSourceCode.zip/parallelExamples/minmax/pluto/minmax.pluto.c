int main() {
    int num, max, min, i,j, out;
    printf("Enter seven numbers:");
    scanf("%d", &num);
    max = min = num;
# CLooG code
    for (i = 0; i < 3; i++) {
        scanf("%d", &num);
        if (max < num)
            max = num;
\PAR
    for (j = 0; i < 3; i++) {
        scanf("%d", &num);
        if (min > num)
            min = num;
    }
# CLooG code
    out = min + max;
    printf("%d ", out);
    return 0;
}
