int main() {
    int num, max, min, i,j, out;
    printf("Enter seven numbers:");
    scanf("%d", &num);
    max = min = num;
# par begin
    for (i = 0; i < 3; i++) {
        scanf("%d", &num);
        if (max < num)
            max = num;
||
    for (j = 0; i < 3; i++) {
        scanf("%d", &num);
        if (min > num)
            min = num;
    }
# par end
    out = min + max;
    printf("%d ", out);
    return 0;
}
