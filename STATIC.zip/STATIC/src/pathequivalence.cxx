#include "Utility.h"
#include "findpath.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<fcntl.h>
#include<time.h>
#include <stdio.h>
#include <sys/time.h>
EXPR subexpr[128];


int compare_trees(NC *t1,NC *t2)
{
	if(t1!=NULL&&t2!=NULL)
	{	
		if(t1->type==t2->type&&t1->inc==t2->inc)
			return compare_trees(t1->link,t2->link)&compare_trees(t1->list,t2->list);
	}
	else if(t1==NULL&&t2==NULL) return 1;
	
	return 0;
}


/*****************************************************************************/

/*   This function check the conditions of two path passing as arguments. 
     It returns 0   if the conditions are not matched.
                1   if conditions are matched.    
                2   if conditions of tempPath matched with that of path but 
                       path has some other conditions also. In this case this 
                       path needs to add to its successor.                   */

/*****************************************************************************/    

int checkCondition(PATH P1, PATH tempPath)
{
      NC *t, *temp;
      int canProceed=0, flag=0;
	 // displayApath(path); 
      t=P1.condition; // R_\beta 
      if(t==NULL) // no condition of execution of the path beta
	  {
			if(tempPath.condition == NULL) // for this path emanates from k
           	{                                    // there is no condition of execution
				canProceed=1; // canProceed=1 indicates both the path and the outward transition have
                              // no condition of execution; so we can proceed for checking the r_\alpha s.
	
		 	}
			else
			{
				canProceed=0; // can not proceed in this path as condition in this outward paths does
								  //not mathched
			}
	 }
	 else // beta have some condition of execution
	 {
			if(tempPath.condition == NULL)
			{
				canProceed=2; //canProceed=2 indicates beta have R_\alpha but this outward path 
							  //has no R_\alpha; still we can proceed as condition may matched in
							  //the path that follows this outward path.
		 	}
			else // outward path has condition of execution
		    {  
			    canProceed=0;
			    temp=tempPath.condition->link;
                while(temp!=NULL)
	     	    {
		              t=P1.condition->link;	     
			          flag=0;
				      while(t!=NULL)
				      {
			            	if(t->inc==0)
				        	{
							    if(compare_trees(t->link,temp->link))
		     			        {
								      flag=1;
   							          break;			     			
								}
					        } 
							t=t->list;
				        }
						if(flag == 0)
						{
						   	canProceed=0;
							break;
						} 
				        temp=temp->list;
				   	}  
					if(temp == NULL)
						canProceed=3; //all components of the condition of this outward path 
 										  // have an equivalent in that of the path. 
					
			} // end else-if(tempPath->condition == NULL)
	}//end else-if(t=NULL)

	if(canProceed == 3) //lets check in other ways. It means check both conditions are totally
						// matched or not. 
	{
			temp=P1.condition->link;
           	while(temp!=NULL)
	        {
		         t=tempPath.condition->link;	     
			     flag=0;
				 while(t!=NULL)
				 {
			        	if(t->inc==0)
					    {
			             	   if(compare_trees(t->link,temp->link))
		     			       {
							      flag=1;
   						          break;			     			
								}
						} 
						t=t->list;
				}
				if(flag == 0)
				{
				   	canProceed=2; //condition of the outward paths partially matched with the
								  // condition of the path. So its required to extend this path 
					break;
				} 
				temp=temp->list;
			}  
			if(temp == NULL)
					canProceed=1; //conditions are totally matched. Need not to extend. 
	}

	return canProceed;	
}

/*****************************************************************************/

/*     Arguments are here two r_alpha ( first one of outward transitions(head)
       and  second one for path transformation(path->transformations)). 
       This function compares them. 
       Returns 1 if they equal; otherwise returns 0          				 */

/*****************************************************************************/

int r_alpha_equal(r_alpha *r1,r_alpha *r2)
{
	r_alpha *temp1,*temp2;
	int flag=0;
	temp1=r1;
	temp2=r2;
	if (temp2==NULL&&temp1==NULL)
       {  
          printf("\n both r_alpha NULL");
		  return 1;
       }
	else if (temp2== NULL) 
				return 0;
		 else if(temp1==NULL) 
				return 0;

      if(compare_trees(temp1->Assign.rhs,temp2->Assign.rhs))
        return 1;
      else return 0;

	/*** successful completetion of this loop gurrentees that all the 
	operation of r2 have an equivalent one in r1; but does not gurrenteed 
    that r1 dont have any extra operation; so we have to check the other direction**/
	/*while(temp2!=NULL)
	{
	    temp1=r1;
	    
        	flag=0;
       		while(temp1!=NULL)
	 	{
			//if(temp2->Assign.lhs==temp1->Assign.lhs)
			//{ 
				if(compare_trees(temp1->Assign.rhs,temp2->Assign.rhs))
				{
				  	flag=1;
					break;
				}
			//}
			temp1=temp1->next;
		}
		if(flag==0)
			return 0;
	    temp2=temp2->next;
   	}

    /** Following loop gurrentees that r1 does not have any extra operation ***/
	/*temp1=r1;
	while(temp1!=NULL)
	{
	    temp2=r2;
	    flag=0;
       		while(temp2!=NULL)
	 	{
			//if(temp2->Assign.lhs==temp1->Assign.lhs)
			//{ 
				if(compare_trees(temp1->Assign.rhs,temp2->Assign.rhs))
				{
				    flag=1;
				    break;
				}
			//}
			temp2=temp2->next;
		}
		if(flag==0)
			return 0;
	    temp1=temp1->next;
   	 }*/

     //return 1;
	 
}
void CorrespondingPlaces(PRESPLUS M0, PRESPLUS M1 ,PATHSET P1, PATHSET P2)
 {
// printf("MDDIJDMDJIDDDJJDJD");
  
  int i,j,n,m,k;
  //PATHSET P1,P2;
  //P1=findpaths(M0);
 // P2=findpaths(M1);
  printf("The corresponding places are ");
  for(i=0;i<M0.no_of_places_initially_marked;i++)
      printf("%s",M0.places[M0.initial_marking[i]].name);

 for(i=0;i<M1.no_of_places_initially_marked;i++)
      printf("%s",M1.places[M1.initial_marking[i]].name);
 for(i=0;i<M0.no_of_places;i++){
  if( M0.places[i].no_of_postset==0)
     printf("%s",M0.places[i].name);
   }

for(i=0;i<M1.no_of_places;i++){
  if( M1.places[i].no_of_postset==0)
     printf("%s",M1.places[i].name);
   }   
    
   for(i=0;i<P1.num_of_path;i++)
   {
    // printf("PATH %d IS CHECKING...............\n\n",i+1);
     for(j=0;j<P2.num_of_path;j++)
    {
      n=r_alpha_equal(P1.path[i].transformations,P2.path[j].transformations);
      m=checkCondition(P1.path[i],P2.path[j]);
    
   if(n==1&&m==1){
     
  for(k=0;k<M0.transitions[P1.path[i].segments[P1.path[i].size-1]].no_of_preset;k++){
      if(M0.places[M0.transitions[P1.path[i].segments[P1.path[i].size-1]].preset[k]].token_present!=1)
     printf("%s\t",M0.places[M0.transitions[P1.path[i].segments[P1.path[i].size-1]].preset[k]].name);
   }
for(k=0;k<M1.transitions[P2.path[j].segments[P2.path[j].size-1]].no_of_preset;k++){
    if(M1.places[M1.transitions[P2.path[j].segments[P2.path[j].size-1]].preset[k]].token_present!=1)
     printf("%s\t",M1.places[M1.transitions[P2.path[j].segments[P2.path[j].size-1]].preset[k]].name); 
  } 

  }
  
  }

 }
}


NC* creat_expr()
{
 NC *S,*T,*P;
 S=(NC*)malloc(sizeof(NC));
 T=(NC*)malloc(sizeof(NC));
 P=(NC*)malloc(sizeof(NC)); 
 //S=root;
 S->inc=0;
 T->inc=0;
 P->inc=0;
 
 S->type='S';
 T->type='T';
 P->type='v';
 S->link=T;
 T->link=P;
 P->link=NULL;
 S->list-NULL;
 T->list=NULL;
 P->list=NULL;
 return S;
    
 }
void make_cmplt(PRESPLUS model,PATHSET paths)
{
  int i,j;
 for(i=0;i<paths.num_of_path;i++)
   {

   for(j=paths.path[i].size-1;j>=0;j--)
       model.transitions[paths.path[i].segments[j]].cmplt=0;
    } 

}

void Associate_R_and_r_alpha(PRESPLUS model,PATHSET paths)
{
   int i,j,k,l,m,n,p,q,r;
   make_cmplt(model,paths);
 for(i=0;i<paths.num_of_path;i++)
   {
   
   // printf("\n///////////////////////////////////PATH %d /////////////////////////// \n",i);
    NC *c1,*prev,*T,*P,*S,*Q;
    r_alpha *temp1,*temp2,*temp3,*temp4,*temp5,*mytemp;
    //r_alpha *temp,*temp4;
     j=0;
    NC *result;
    NC *temp_rhs, *nc_ptr,*tmp_rhs;	
    char ch[1],c;
    char *sym_value;
        sym_value = (char * ) malloc( 100*sizeof( char ) );
    int index;
    TRANSITION *trans,*temp;
    
    result=NULL;
    prev=NULL;
    if(paths.path[i].size!=0)
         
     j=paths.path[i].size-1; 
    while(j>=0)
    {
           c1=copylist(model.transitions[paths.path[i].segments[j]].condition);
           if(c1!=NULL)
           {
	    //   temp1=path->transformations;
	    //   while(temp1!=NULL)
	    //   {

	       // 	c1=substitute_in_condition(c1,temp1->Assign.lhs,temp1->Assign.rhs);
		//        temp1=temp1->next;
	    //   }
               if(result==NULL)
               {
                    result=c1;
                    //	printf("\n the condition before applying DTS \n");
            	   //write_lists(result);
            	    	printf("\n\n"); 
                    prev=c1->link;		    			
               }
               else
               {    
               	   prev->list=c1->link;
           	 //  prev=prev->list;
                 //  free(c1);
               }
		while(prev->list !=NULL)
		{
		    prev=prev->list;
			    
		}

           } 
          
            // printf("\n??????????????????POSTSET PLACES??????????\n");
            //for(m=0;m<model.transitions[paths.path[i].segments[j]].no_of_postset;m++)
               //write_lists(model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].rhs);
              // printf("\nPOST PLACES\n");
            if(model.transitions[paths.path[i].segments[j]].cmplt==0){
              p=paths.path[i].size-1;
            if(j==p)
              {
               for(m=0;m<model.transitions[paths.path[i].segments[j]].no_of_postset;m++){
                    //ch=(char*)malloc(sizeof(char)*1);
                   ch[0]=model.var_table[model.places[model.transitions[paths.path[i].segments[j]].postset[m]].var_index].name;  
                   model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].lhs=indexof_symtab(ch);
                   model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].rhs=copylist(model.transitions[paths.path[i].segments[j]].action[0].rhs);
                   // printf("\nIN PLACES\n%c=",ch[0]);
                  //write_lists(model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].rhs);
                  //  printf("\n");
                     }
                     temp4=(r_alpha*)malloc(sizeof(r_alpha));
                     temp4->Assign.lhs=model.places[model.transitions[paths.path[i].segments[j]].postset[m-1]].trans[0].lhs;
                     temp4->Assign.rhs=copylist(model.places[model.transitions[paths.path[i].segments[j]].postset[m-1]].trans[0].rhs); 
                      //write_lists(model.places[model.transitions[paths.path[i].segments[j]].postset[m-1]].trans[0].rhs);      
                     paths.path[i].transformations=temp4;
                     
                    // printf("\nIT is Transformation\n");
                   // write_lists(temp4->Assign.rhs);
                  //  printf("\n");
                    //free(temp4);
                 model.transitions[paths.path[i].segments[j]].cmplt=1;
                }
         else
            {
              if(model.transitions[paths.path[i].segments[j]].no_of_preset==1)
                {
                   temp4=(r_alpha*)malloc(sizeof(r_alpha));
                   temp4->Assign.rhs=creat_expr();
                   temp4->Assign.lhs=model.transitions[paths.path[i].segments[j]].action[0].lhs;
                   //write_lists(model.transitions[paths.path[i].segments[j]].action[0].rhs);
                  //printf("Enterr%d\n", model.transitions[paths.path[i].segments[j]].action[0].rhs->inc);
                 temp4->Assign.rhs->inc=model.transitions[paths.path[i].segments[j]].action[0].rhs->inc+model.places[model.transitions[paths.path[i].segments[j]].preset[0]].trans[0].rhs->inc;
                   temp4->Assign.rhs->inc=temp4->Assign.rhs->inc*model.transitions[paths.path[i].segments[j]].action[0].rhs->link->inc;
                   temp4->Assign.rhs->link->inc=model.transitions[paths.path[i].segments[j]].action[0].rhs->link->inc*model.places[model.transitions[paths.path[i].segments[j]].preset[0]].trans[0].rhs->link->inc;
                   temp4->Assign.rhs->link->link->inc=model.places[model.transitions[paths.path[i].segments[j]].preset[0]].trans[0].rhs->link->link->inc;
                  
                   for(m=0;m<model.transitions[paths.path[i].segments[j]].no_of_postset;m++){
                   ch[0]=model.var_table[model.places[model.transitions[paths.path[i].segments[j]].postset[m]].var_index].name;  
                   model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].lhs=indexof_symtab(ch);
                   model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].rhs=copylist(temp4->Assign.rhs);
                    // printf("\nIN ELSE PART\n%c=",ch[0]);
                     // write_lists(model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].rhs);
                    // printf("\n");
                     }
                      paths.path[i].transformations=temp4;
                     // printf("\nEND IF\n");
                   model.transitions[paths.path[i].segments[j]].cmplt=1;
                  }
             else{
                  //printf("\nElse BEGIN\n");
                  S=(NC*)malloc(sizeof(NC));
                 // Q=(NC*)malloc(sizeof(NC));
                  S=model.transitions[paths.path[i].segments[j]].action[0].rhs;
                     // printf("S\n");
                    //write_lists(model.transitions[paths.path[i].segments[j]].action[0].rhs);
                     //printf("\n");
                    temp4=(r_alpha*)malloc(sizeof(r_alpha));
                 
                  temp4->Assign.lhs=model.transitions[paths.path[i].segments[j]].action[0].lhs;
                  temp4->Assign.rhs=creat_expr();
                  
                 // printf("\nTEMP4 at THE BEGINING\n");
                  
                   // printf("\n");
                 
                 while(S->link!=NULL)
                 {
                      // printf("\nIN WHILE\n");
                  temp5=(r_alpha*)malloc(sizeof(r_alpha));
                  temp5->Assign.rhs=creat_expr();
                 
                  for(m=0;m<model.transitions[paths.path[i].segments[j]].no_of_preset;m++)
                   {
                      //printf("\nIN FOR\n");
                   
                     symbol_for_index( model.transitions[paths.path[i].segments[j]].action[0].rhs->link->link->inc, sym_value );
                  // printf("%s-->%c-->%c\n",model.transitions[paths.path[i].segments[j]].name,model.var_table[model.places[model.transitions[paths.path[i].segments[j]].preset[m]].var_index].name,sym_value[0]);
                   //write_lists(model.transitions[paths.path[i].segments[j]].action[0].rhs);
                   //printf("\n");
                  if(model.var_table[model.places[model.transitions[paths.path[i].segments[j]].preset[m]].var_index].name==sym_value[0])
                    {
                       //printf("\nIN IF\n");
                     //  printf("\nPlace is matched %s\n",model.places[model.transitions[paths.path[i].segments[j]].preset[m]].name);
                  
                      //printf("\npreset place matched %s\n",model.places[model.transitions[paths.path[i].segments[j]].preset[m]].name);
                     
                      temp5->Assign.rhs->inc=model.places[model.transitions[paths.path[i].segments[j]].preset[m]].trans[0].rhs->inc*model.transitions[paths.path[i].segments[j]].action[0].rhs->link->inc;
                     
                      
                      temp5->Assign.rhs->link->inc=model.transitions[paths.path[i].segments[j]].action[0].rhs->link->inc*model.places[model.transitions[paths.path[i].segments[j]].preset[m]].trans[0].rhs->link->inc;
                      //T->type='T';
                      //temp5->Assign.rhs->link=T;
                      //temp5->Assign.rhs->link->link=P;
                      temp5->Assign.rhs->link->link->inc=model.places[model.transitions[paths.path[i].segments[j]].preset[m]].trans[0].rhs->link->link->inc;
                      // printf("\ntemp5\n");
                       // write_lists(temp5->Assign.rhs);
                        // printf("\n");
                        break;       
                     }
                    
                 }
                  if(temp4->Assign.rhs->link->inc==0){
                  //temp4->Assign.rhs=copylist(temp5->Assign.rhs);
                        // printf("(%d)",temp4->Assign.rhs->inc);
                        temp4->Assign.rhs->inc=temp5->Assign.rhs->inc;
                        temp4->Assign.rhs->link->inc=temp5->Assign.rhs->link->inc;
                        temp4->Assign.rhs->link->link->inc=temp5->Assign.rhs->link->link->inc;
                        // printf("\ntemp4\n");
                         // write_lists(temp4->Assign.rhs);
                        // printf("\n");
                               
                     }
                  else
                      {
                        temp4->Assign.rhs->inc=temp4->Assign.rhs->inc+temp5->Assign.rhs->inc;
                        temp4->Assign.rhs->link->inc=temp4->Assign.rhs->link->inc+temp5->Assign.rhs->link->inc;
                        temp4->Assign.rhs->link->inc=temp5->Assign.rhs->link->inc;
                       } 
                   S->link=model.transitions[paths.path[i].segments[j]].action[0].rhs->link->list;
               }
                for(m=0;m<model.transitions[paths.path[i].segments[j]].no_of_postset;m++){
                   ch[0]=model.var_table[model.places[model.transitions[paths.path[i].segments[j]].postset[m]].var_index].name;  
                   model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].lhs=indexof_symtab(ch);
                   model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].rhs=copylist(temp4->Assign.rhs);
                     // printf("%c=",ch[0]);
                     // write_lists( model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].rhs);
                       //  printf("\n");
                    // write_lists( model.transitions[paths.path[i].segments[j]].action[0].rhs);
                    // printf("\n");
                       }
                paths.path[i].transformations=temp4;
               // printf("\nIT is transformation\n");
                 // write_lists(temp4->Assign.rhs);
                      //   printf("\n"); 
              // write_lists( model.transitions[paths.path[i].segments[j]].action[0].rhs);
                  //   printf("\n"); 
              model.transitions[paths.path[i].segments[j]].cmplt=1;
           
          /* else //if(model.transitions[paths.path[i].segments[j]].action[0].rhs->link->link->link!=NULL)
                   {
                    printf("LAST ELSE ENTERED");
                    temp4=(r_alpha*)malloc(sizeof(r_alpha));
                    temp4->Assign.lhs=model.transitions[paths.path[i].segments[j]].action[0].lhs;
                    temp4->Assign.rhs=creat_expr();
                  //temp4->Assign.rhs->inc=model.transitions[paths.path[i].segments[j]].action[0].rhs->inc;
               while(model.transitions[paths.path[i].segments[j]].action[0].rhs->link!=NULL)
                {
              for(m=0;m<model.transitions[paths.path[i].segments[j]].no_of_preset;m++)
                {
                  index=indexof_symtab(model.places[model.transitions[paths.path[i].segments[j]].preset[m]].name);
                  if(model.transitions[paths.path[i].segments[j]].action[0].rhs->link->link->inc==index)
                    {
                  //temp4->Assign.rhs->inc=model.transitions[paths.path[i].segments[j]].action[0].rhs->inc;
                      temp5=(r_alpha*)malloc(sizeof(r_alpha));
                      //temp5->Assign.lhs=index;
                      temp5->Assign.rhs=creat_expr();
                      temp5->Assign.rhs->inc=model.places[model.transitions[paths.path[i].segments[j]].preset[m]].trans[0].rhs->inc;
                      temp5->Assign.rhs->link->inc=model.places[model.transitions[paths.path[i].segments[j]].preset[m]].trans[0].rhs->link->inc;
                      temp5->Assign.rhs->link->link->inc=model.places[model.transitions[paths.path[i].segments[j]].preset[m]].trans[0].rhs->link->link->inc;
                       break;                
                     }
                 }
                  if(temp4->Assign.rhs->link->inc==0){
                     
                     //temp4->Assign.rhs=copylist(temp5->Assign.rhs);
                        temp4->Assign.rhs->inc=temp5->Assign.rhs->inc;
                        temp4->Assign.rhs->link->inc=temp5->Assign.rhs->link->inc;
                        temp4->Assign.rhs->link->inc=temp5->Assign.rhs->link->inc;
                      }  
                  else
                      {
                        temp4->Assign.rhs->inc=temp4->Assign.rhs->inc+temp5->Assign.rhs->inc;
                        temp4->Assign.rhs->link->inc=temp5->Assign.rhs->link->inc*temp5->Assign.rhs->link->inc;
                        temp5->Assign.rhs->link->inc=temp5->Assign.rhs->link->inc;
                       } 
                  model.transitions[paths.path[i].segments[j]].action[0].rhs->link=model.transitions[paths.path[i].segments[j]].action[0].rhs->link->link;
               }
                for(m=0;m<model.transitions[paths.path[i].segments[j]].no_of_postset;m++){
                   ch[0]=model.var_table[model.places[model.transitions[paths.path[i].segments[j]].postset[m]].var_index].name;  
                   model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].lhs=indexof_symtab(ch);
                   model.places[model.transitions[paths.path[i].segments[j]].postset[m]].trans[0].rhs=copylist(temp4->Assign.rhs);
                       }
                paths.path[i].transformations=temp4;
                   }
                
             */
          //free(S);
          }
     
        }
                      
         }
    
          
           j=j-1;
    }
    
    paths.path[i].condition=result;
   
  write_lists(result);
  
  mytemp=paths.path[i].transformations;
 write_lists(mytemp->Assign.rhs);
		  /*while(temp1!=NULL)
		  {
		          //symbol_for_index( temp1->Assign.lhs, sym_value );
			//  printf("\n %s := ", sym_value );
			  
			  write_lists(temp1->Assign.rhs);
			  mytemp=mytemp->next;
		  }
                 printf("\n");*/
  
} 
}
/*void pathcomputation(PRESPLUS model,PATHSET paths)
{

  char *sym_value;
        sym_value = (char * ) malloc( 1000*sizeof( char ) );

    r_alpha *temp1;

   int i=0,j,k;
	 for(i=0;i<paths.num_of_path;i++) {
          
              printf("\n//////////////////path %d/////////////////////\n\n",i+1);
      
              //k=paths.path[i].size-1;
                      
              printf("\ncondition:");
              write_lists(paths.path[i].condition);
              printf("\nTransformation:");
               temp1=paths.path[i].transformations;
		  while(temp1!=NULL)
		  {
		          symbol_for_index( temp1->Assign.lhs, sym_value );
			  printf("\n %s := ", sym_value );
			  
			  write_lists(temp1->Assign.rhs);
			  temp1=temp1->next;
		  }
                 printf("\n");
          }

}*/
EXPR findsubexpr(EXPR expr)
{
  EXPRNODE tmp = *expr ;
 if(tmp.value==7)
     return expr->right;

 else findsubexpr(expr->left);
}
char findleft(EXPR expr)
{
  EXPRNODE tmp = *expr ;
  if(expr->left==NULL)
   return tmp.value;
  else findleft(expr->left);

}

int Validation(PRESPLUS model,PATHSET P)
  {
    Initial(&model);
    int i,j;
    for(i=0;i<P.num_of_path;i++)
       for(j=0;j<P.path[i].size;j++)
          model.transitions[P.path[i].segments[j]].mark=1;
    
     for(i=0;i<model.no_of_transitions;i++)
        {
          if(model.transitions[i].mark!=1)
            return 0;
        }
       for(i=0;i<P.num_of_path;i++){
           if(model.places[model.transitions[P.path[i].segments[P.path[i].size-1]].preset[0]].label==2)
             {

               if(model.places[model.transitions[P.path[i].segments[0]].postset[0]].label!=2)
                        return 0;
             }
          }
       return 1;
      
 }    

void findEquivalent(PRESPLUS M0,PRESPLUS M1)
{
  printf("\n\n");
  PATHSET P1,P2;
  int i,j,n,m,count=0,temp;
  char *sym_value;
        sym_value = (char * ) malloc( 1000*sizeof( char ) );
  r_alpha *temp1;

       // int i,p;  	
	//int tfront;

        struct timeval tv1;
	struct timezone tz1;
	struct timeval tv2;
	struct timezone tz2;
        gettimeofday(&tv1, &tz1);
       P1=ConstructAllPaths(&M0);
       P2=ConstructAllPaths(&M1);
       if(Validation(M0,P1)&&Validation(M1,P2)){
         printf("<--------------------The Models are Valid----------------->\n");
       Associate_R_and_r_alpha(M0,P1);
      // pathcomputation(M1,P1);
       Associate_R_and_r_alpha(M1,P2);
      // pathcomputation(M1,P2);
     //CorrespondingPlaces(M0,M1,P1,P2);
   printf("\n##################### PATH  EQUIVALANCE #######################\n\n");
   
   for(i=0;i<P1.num_of_path;i++)
   {//n=1;m=1;
     printf("PATH %d IS CHECKING...............\n\n",i+1);
     for(j=0;j<P2.num_of_path;j++)
    {
      n=r_alpha_equal(P1.path[i].transformations,P2.path[j].transformations);
      m=checkCondition(P1.path[i],P2.path[j]);
     //printf("\n%d-->%d\n",n,m);
      if(n==1&&m==1){
        count++,temp=i;
        printf("PATH %d OF MODEL 1 IS MATCHED WITH PATH %d OF MODEL 2\n\n",i+1,j+1);
        printf("\nTHE CONDITION IS\n");
        write_lists(P1.path[i].condition);
         printf("\nTHE TRANSFORMATION IS\n");
          temp1=P1.path[i].transformations;
           write_lists(temp1->Assign.rhs);
		  /*while(temp1!=NULL)
		  {
		          symbol_for_index( temp1->Assign.lhs, sym_value );
			  printf("\n %s := ", sym_value );
			  
			  write_lists(temp1->Assign.rhs);
			  temp1=temp1->next;
		  }
                 printf("\n");*/
             
         }//end if
           
    } 
   if(temp!=i)
     printf("\n\n>>>>Failed to find the corresponding path %d of MODEL 1 in MODEL 2>>> \n \n ",i+1);

  }
  if(count==P1.num_of_path)
  {
  printf("\n\n<<<<<<<<<<<<<<<<< THE TWO MODEL ARE EQUIVALENT >>>>>>>>>>>>>>>>>\n\n");

 }  
else
    printf("\n\n<<<<<<<<<<<<<<<<<< THE TWO MODEL ARE NOT EQUIVALENT >>>>>>>>>>>>>>>>>>>\n\n"); 

printf("\n\n\n\n###################### Verification Report #######################\n\n");

 printf("\n No. of states in M0: %d and No. of states in M1: %d\n", M0.no_of_places, M1.no_of_places);

 printf("\n No. of paths in initial path cover of M0: %d and No. of paths in actual path cover of M0: %d\n", 
        P1.num_of_path, P2.num_of_path);
  gettimeofday(&tv2, &tz2);
  printf("\n Exec time is %ld sec and %ld microsecs\n", tv2.tv_sec - tv1.tv_sec, tv2.tv_usec - tv1.tv_usec);
 }
}


