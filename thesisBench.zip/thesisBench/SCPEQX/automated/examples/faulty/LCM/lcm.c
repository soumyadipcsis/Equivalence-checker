 #include<stdio.h>
void main()
{
    int y1, y2, res, yout, yout1, i;
    res=1;
    for(i=0;y1!=y2;i++)
    {
        if(y1%2==0)
            if(y2%2==0)
            {
               
                y1=y1/2;
                y2=y2/2;
            }        
            else
                y1=y1/2;
        else if(y2%2==0)
                y2=y2/2;
             else if(y1>y2)
                    y1=y1-y2;
                  else
                    y2=y2-y1;
    }
    res=res*y1;
    yout=res;
    yout1=(y1*y2)/yout;
    printf ("%d", yout1);
}



    
