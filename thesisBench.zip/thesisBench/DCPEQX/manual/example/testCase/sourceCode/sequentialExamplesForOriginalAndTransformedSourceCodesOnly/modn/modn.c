#include<stdio.h>
void main()
{
int s, i, n, a, b,sout;
s=0;
for(i=0;i<=15;i++)
{
if(b%2==1)
	s=s+a;
if(s>=n)
	s=s-n;
a=a*2;
b=b/2;
if(a>=n)	
	a=a-n;
}
sout=s;
}
