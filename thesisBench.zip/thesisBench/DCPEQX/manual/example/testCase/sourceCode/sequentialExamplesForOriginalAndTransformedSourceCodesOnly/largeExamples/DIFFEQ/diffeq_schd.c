void main ()
{
	int i;
	int x;
	int a;
	int sT1_9;
	int dx;
	int sT3_9;
	int u;
	int sT4_9;
	int y;
	int sT5_9;
	int t4;
	int t1;
	int t2;
	int t3;
	int t6;
	int t5;
	int y1;
	int xout;
	int yout;
	int uout;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
  q00:
		i=0;
		goto q01;
  q01:

	if (x<a)
 	{
		sT1_9=x+dx;
		sT3_9=u*dx;
		sT4_9=y*3;
		sT5_9=x*3;
		goto q02;
	}

	else
 	{
		goto q013;
	}
  q02:
		t4=sT3_9*sT5_9;
		t1=sT3_9;
		t2=sT5_9;
		t3=sT4_9;
		x=sT1_9;
		i=i+1;
		goto q03;
  q03:
		t6=u-t4;
		t5=dx*sT4_9;
		goto q04;
  q04:
		u=t6-t5;
		goto q05;
  q05:
		y1=u*dx;
		goto q06;
  q06:
		y=y+y1;
		goto q01;
  q013:
		xout=x;
		yout=y;
		uout=u;
		goto q015;
  q015:
	;
}
