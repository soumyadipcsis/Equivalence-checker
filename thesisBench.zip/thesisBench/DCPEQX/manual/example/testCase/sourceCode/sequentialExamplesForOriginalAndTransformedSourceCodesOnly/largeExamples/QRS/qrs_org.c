void main ()
{
	int rdy;
	int RRpeak;
	int fl3o;
	int RRo;
	int y0m1;
	int y0m2;
	int ymax;
	int xmax;
	int zmax;
	int RR;
	int lymax;
	int lzmax;
	int lxmax;
	int fl3;
	int fl1;
	int fl2;
	int count;
	int low;
	int data;
	int high;
	int indx;
	int ftm1;
	int ecgm1;
	int i;
	int ecg1;
	int t1;
	int t2;
	int t3;
	int t4;
	int ft;
	int ysi;
	int ftm2;
	int y0;
	int ath;
	int ys;
	int t5;
	int t6;
	int t7;
	int t8;
	int t9;
	int t10;
	int t11;
	int t12;
	int sth2;
	int sth1;
	int t13;
	int t14;
	int t15;
	int t16;
	int t17;
	int t18;
	int t19;
	int t20;
	int t21;
	int t22;
	int t23;
	int t24;
	int rdy2;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
  q00:
		rdy=0;
		RRpeak=0;
		fl3o=0;
		RRo=0;
		y0m1=0;
		y0m2=0;
		ymax=0;
		xmax=0;
		zmax=0;
		RR=0;
		lymax=0;
		lzmax=0;
		lxmax=0;
		fl3=0;
		fl1=0;
		fl2=0;
		count=0;
		goto q01;
  q01:
		rdy=1;
		goto q02;
  q02:
		low=data;
		rdy=0;
		goto q03;
  q03:
		rdy=1;
		goto q04;
  q04:
		high=data;
		rdy=0;
		goto q05;
  q05:
		rdy=1;
		goto q06;
  q06:
		indx=data;
		rdy=0;
		goto q07;
  q07:
		rdy=1;
		goto q08;
  q08:
		ftm1=data;
		goto q09;
  q09:
		ecgm1=ftm1;
		i=1;
		goto q010;
  q010:

	if (i<=indx)
 	{
		rdy=0;
		goto q011;
	}

	else
 	{
		goto q030;
	}
  q011:
		rdy=1;
		i=i+1;
		goto q012;
  q012:
		ecg1=data;
		goto q013;
  q013:
		t1=ecg1-ecgm1;
		t2=ecg1-ecgm1;
		goto q014;
  q014:
		t3=t2/256;
		t4=ftm1+t1;
		goto q015;
  q015:
		ft=ftm1;
		goto q017;
  q017:
		ysi=ft-ftm2;
		goto q018;
  q018:

	if (ysi>ymax)
 	{
		ymax=ysi;
		goto q019;
	}

	else
 	{
		goto q019;
	}
  q019:

	if (ft>xmax)
 	{
		xmax=ft;
		goto q020;
	}

	else
 	{
		goto q020;
	}
  q020:

	if (ft>0)
 	{
		y0=ft;
		goto q021;
	}

	else
 	{
		goto q021;
	}
  q021:
		ath=xmax/4;
		goto q023;
  q023:

	if (ath>y0)
 	{
		y0=ath;
		goto q024;
	}

	else
 	{
		goto q024;
	}
  q024:
		ys=y0-y0m2;
		goto q025;
  q025:

	if (ys>zmax)
 	{
		zmax=ys;
		goto q026;
	}

	else
 	{
		goto q026;
	}
  q026:
		ftm2=ftm1;
		ftm1=ft;
		ecgm1=data;
		y0m2=y0m1;
		y0m1=y0;
		t5=ymax/2;
		t6=ymax/8;
		t7=ymax/16;
		t8=zmax/2;
		t9=zmax/8;
		t10=zmax/16;
		goto q027;
  q027:
		t11=t5+t6;
		t12=t8+t9;
		goto q028;
  q028:
		sth2=t12+t10;
		goto q030;
  q030:

	if (ysi>sth1)
 	{
		fl1=0;
		count=0;
		goto q031;
	}

	else
 	{
		goto q031;
	}
  q031:

	if (ys>sth2)
 	{
		fl2=0;
		count=0;
		goto q032;
	}

	else
 	{
		goto q032;
	}
  q032:

	if (fl1==1&&fl2==1&&RR>low)
 	{
		RRpeak=1;
		t13=xmax/2;
		t14=xmax/4;
		t15=lxmax/8;
		t16=ymax/2;
		t17=ymax/4;
		t18=lymax/8;
		t19=zmax/2;
		t20=zmax/4;
		t21=lzmax/8;
		goto q033;
	}

	else
 	{
		RRpeak=0;
		goto q036;
	}
  q033:
		t22=t13+t14;
		t23=t16+t17;
		t24=t19+t20;
		goto q035;
  q035:
		RR=0;
		count=0;
		fl1=0;
		fl2=0;
		fl3=0;
		lxmax=0;
		lymax=0;
		lzmax=0;
		goto q036;
  q036:

	if (fl1==1||fl2==1)
 	{
		count=count+1;
		goto q037;
	}

	else
 	{
		goto q037;
	}
  q037:
		fl3o=fl3;
		RRo=RR;
		rdy2=0;
		goto q038;
  q038:
		rdy2=1;
		ecg1=data;
		goto q039;
  q039:
		t1=ecg1-ecgm1;
		goto q040;
  q040:
		t2=t1/256;
		t4=ftm1+t1;
		goto q041;
  q041:
		ysi=ft-ftm2;
		goto q042;
  q042:

	if (ysi>lymax)
 	{
		lymax=ysi;
		goto q043;
	}

	else
 	{
		goto q043;
	}
  q043:

	if (ft>lxmax)
 	{
		lxmax=ft;
		goto q044;
	}

	else
 	{
		goto q044;
	}
  q044:

	if (ft>0)
 	{
		y0=ft;
		goto q045;
	}

	else
 	{
		goto q045;
	}
  q045:
		ath=xmax/4;
		goto q046;
  q046:

	if (y0<ath)
 	{
		y0=ath;
		goto q047;
	}

	else
 	{
		goto q047;
	}
  q047:
		ys=y0-y0m2;
		goto q048;
  q048:

	if (ys>lzmax)
 	{
		lzmax=ys;
		goto q049;
	}

	else
 	{
		goto q049;
	}
  q049:

	if (count==8)
 	{
		fl1=0;
		fl2=0;
		count=0;
		goto q050;
	}

	else
 	{
		goto q050;
	}
  q050:

	if (RR>high)
 	{
		fl3=fl3+1;
		RR=0;
		ymax=ymax/2;
		zmax=zmax/2;
		goto q051;
	}

	else
 	{
		goto q051;
	}
  q051:
		t5=ymax/2;
		t6=ymax/8;
		t7=ymax/16;
		t8=zmax/2;
		t9=zmax/8;
		t10=zmax/16;
		goto q052;
  q052:
		t11=t5+t6;
		t12=t8+t9;
		goto q053;
  q053:
	;
}
