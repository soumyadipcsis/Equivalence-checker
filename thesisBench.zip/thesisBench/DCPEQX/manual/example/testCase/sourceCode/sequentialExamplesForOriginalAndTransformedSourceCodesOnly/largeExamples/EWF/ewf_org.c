void main ()
{
	int inp;
	int p10;
	int b;
	int p20;
	int c;
	int p30;
	int d;
	int p11;
	int e;
	int p21;
	int f;
	int p31;
	int g;
	int p12;
	int h;
	int p22;
	int x;
	int p32;
	int v1;
	int v2;
	int v3;
	int v5;
	int v6;
	int v7;
	int v8;
	int v9;
	int v11;
	int v12;
	int v13;
	int v14;
	int v17;
	int v19;
	int v18;
	int v20;
	int v21;
	int v22;
	int v23;
	int v27;
	int v29;
	int v24;
	int v25;
	int v26;
	int v31;
	int v32;
	int v30;
	int v28;
	int out;
	int p4;
	int p5;
	int p6;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
  S0:
		inp=p10;
		b=p20;
		goto S1;
  S1:
		c=p30;
		d=p11;
		goto S2;
  S2:
		e=p21;
		f=p31;
		goto S4;
  S4:
		g=p12;
		h=p22;
		goto S5;
  S5:
		x=p32;
		goto S6;
  S6:
		v1=b+inp;
		goto S7;
  S7:
		v2=e+f;
		goto S8;
  S8:
		v3=v1+c;
		goto S9;
  S9:
		goto S10;
  S10:
		v5=v3+d;
		goto S11;
  S11:
		v6=v5+v2;
		goto S12;
  S12:
		v7=v6*x;
		goto S13;
  S13:
		v8=v7;
		goto S14;
  S14:
		v9=v3+v7;
		goto S16;
  S16:
		v11=v9+v6;
		v12=v8+v2;
		v13=v3+v9;
		goto S18;
  S18:
		d=v11+v12;
		v14=v13*x;
		v17=v12+v2;
		goto S19;
  S19:
		v19=v17*x;
		goto S20;
  S20:
		v18=v14+v1;
		goto S21;
  S21:
		v20=v9+v18;
		v21=v19+f;
		v22=v1+v18;
		goto S22;
  S22:
		v23=v20+g;
		v27=v21+f;
		v29=v22*x;
		goto S23;
  S23:
		v24=v12+v21;
		v25=v23*x;
		goto S24;
  S24:
		v26=v24+h;
		c=v23+g;
		goto S25;
  S25:
		v31=v26*x;
		v32=v27*x;
		goto S26;
  S26:
		v30=v29+inp;
		goto S27;
  S27:
		v28=v25+g;
		h=h+v31;
		out=v32;
		goto S29;
  S29:
		b=v30+v18;
		e=v26+h;
		g=v28;
		goto S30;
  S30:
		p4=out;
		p5=h;
		goto S31;
  S31:
		p6=b;
		p4=c;
		goto S32;
  S32:
		p5=e;
		p4=g;
		goto S33;
  S33:
		p6=f;
		p5=d;
		goto S34;
  S34:
	;
}
