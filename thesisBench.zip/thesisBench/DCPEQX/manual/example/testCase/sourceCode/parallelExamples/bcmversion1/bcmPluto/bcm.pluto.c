#include <stdio.h>

int main()
{ 

int a,b,c,d,e,f,g,h,i,j,k,l,m;


# CLooG code 

  a=b+c;
  d=e+f;
  g=a+d;

\PAR

  h=i+j;
  k=l+m;
  o=h+k;

# CLooG code
}
