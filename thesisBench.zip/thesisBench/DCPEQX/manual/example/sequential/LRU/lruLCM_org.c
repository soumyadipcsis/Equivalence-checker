void main ()
{
	int eop;
	int breakLoop;
	int clk;
	int X;
	int Y;
	int reset;
	int found;
	int newGuy;
	int mru;
	int i;
	int last;
	int temp;
	int j;
	int temp2;
	int temp_list;
	int list;
	int pushTo;
	int temp1;
	int temp3;
	int temp4;
	int lru;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
  q000:
		eop=0;
		breakLoop=0;
		goto q001;
  q001:

	if (clk!=1)
 	{
		goto q001;
	}

	else
 	{
		goto q002;
	}
  q002:

	if (eop==0)
 	{
		X=100;
		Y=200;
		goto q003;
	}

	else
 	{
		goto q033;
	}
  q003:

	if (clk!=1)
 	{
		goto q003;
	}

	else
 	{
		goto q004;
	}
  q004:

	if (reset==1)
 	{
		eop=1;
		breakLoop=1;
		goto q005;
	}

	else
 	{
		eop=0;
		breakLoop=0;
		goto q005;
	}
  q005:

	if (eop==0)
 	{
		found=0;
		newGuy=mru;
		i=0;
		goto q006;
	}

	else
 	{
		goto q002;
	}
  q006:

	if (i<last&&found==0&&breakLoop==0)
 	{
		temp=0;
		j=0;
		goto q007;
	}

	else
 	{
		goto q014;
	}
  q007:

	if (j<=i)
 	{
		temp=temp*256;
		j=j+1;
		goto q007;
	}

	else
 	{
		temp2=temp+8;
		goto q009;
	}
  q009:
		temp_list=list%temp2;
		goto q010;
  q010:
		temp_list=temp_list/temp;
		goto q011;
  q011:

	if (temp_list==newGuy)
 	{
		found=1;
		goto q012;
	}

	else
 	{
		i=i+1;
		goto q012;
	}
  q012:

	if (clk!=1)
 	{
		goto q012;
	}

	else
 	{
		eop=0;
		breakLoop=0;
		goto q013;
	}
  q013:

	if (reset==1)
 	{
		eop=1;
		breakLoop=1;
		goto q006;
	}

	else
 	{
		goto q006;
	}
  q014:

	if (eop==0)
 	{
		eop=0;
		goto q015;
	}

	else
 	{
		goto q002;
	}
  q015:

	if (found==1)
 	{
		pushTo=i;
		goto q018;
	}

	else
 	{
		goto q016;
	}
  q016:

	if (last<7)
 	{
		pushTo=last+1;
		goto q017;
	}

	else
 	{
		pushTo=last;
		goto q017;
	}
  q017:
		last=pushTo;
		goto q018;
  q018:

	if (clk!=1)
 	{
		goto q018;
	}

	else
 	{
		goto q019;
	}
  q019:

	if (reset==1)
 	{
		eop=1;
		goto q020;
	}

	else
 	{
		goto q020;
	}
  q020:

	if (eop==0)
 	{
		temp=0;
		j=0;
		eop=0;
		goto q021;
	}

	else
 	{
		goto q002;
	}
  q021:

	if (j<=pushTo)
 	{
		temp=temp*256;
		j=j+1;
		goto q021;
	}

	else
 	{
		temp_list=list%temp;
		goto q022;
	}
  q022:
		temp_list=temp_list*256;
		temp1=temp*256;
		goto q023;
  q023:
		list=list/temp1;
		goto q024;
  q024:
		list=list*temp1;
		goto q025;
  q025:
		list=list+temp_list;
		goto q026;
  q026:

	if (reset==1)
 	{
		eop=1;
		goto q027;
	}

	else
 	{
		goto q027;
	}
  q027:

	if (eop==0)
 	{
		list=list/256;
		goto q028;
	}

	else
 	{
		goto q002;
	}
  q028:
		list=list*256;
		temp3=last+1;
		goto q029;
  q029:
		list=list+newGuy;
		temp3=temp3*256;
		temp4=last*256;
		goto q030;
  q030:
		temp_list=list%temp3;
		goto q031;
  q031:
		temp_list=temp_list/temp4;
		goto q032;
  q032:
		lru=temp_list;
		goto q002;
  q033:
	;
}
