#include <stdio.h>

void main ()
{
    /* Soumyadip's Program. */
    int a, b, c, d;
    a = 5;
    if (a > 0)
        b = a;
    else
        c = a;
    
    d = b + c;
    
}
