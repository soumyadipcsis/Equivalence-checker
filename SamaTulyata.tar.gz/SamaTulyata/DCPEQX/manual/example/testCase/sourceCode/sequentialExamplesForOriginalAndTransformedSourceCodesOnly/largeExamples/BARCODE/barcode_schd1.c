void main ()
{
	int wh;
	int bl;
	int eoc;
	int memw;
	int data;
	int addr;
	int eop;
	int breakflag;
	int clk;
	int reset;
	int start;
	int actnum;
	int num;
	int white;
	int scan;
	int flag;
	int black;
	int video;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
  q000:
		wh=0;
		bl=1;
		eoc=0;
		memw=0;
		data=0;
		addr=0;
		eop=0;
		goto q001;
  q001:

	if (eop==0)
 	{
		breakflag=0;
		goto q002;
	}

	else
 	{
		goto q031;
	}
  q002:

	if (breakflag!=1)
 	{
		goto q003;
	}

	else
 	{
		goto q006;
	}
  q003:

	if (clk!=1)
 	{
		goto q003;
	}

	else
 	{
		eop=0;
		goto q004;
	}
  q004:

	if (reset==1&&start==1)
 	{
		eop=1;
		breakflag=1;
		goto q002;
	}

	else if (reset==1&&! (start==1) )
 	{
		eop=1;
		breakflag=1;
		goto q002;
	}

	else if (! (reset==1) &&start==1)
 	{
		breakflag=1;
		goto q002;
	}

	else
 	{
		goto q002;
	}
  q006:

	if (eop==0)
 	{
		breakflag=0;
		goto q007;
	}

	else
 	{
		goto q001;
	}
  q007:

	if (actnum!=num&&white!=255&&breakflag==0&&eop==0)
 	{
		breakflag=0;
		goto q008;
	}

	else
 	{
		goto q001;
	}
  q008:

	if (breakflag!=1)
 	{
		goto q009;
	}

	else
 	{
		goto q012;
	}
  q009:

	if (clk!=1)
 	{
		goto q009;
	}

	else
 	{
		eop=0;
		goto q010;
	}
  q010:

	if (reset==1&&scan==1)
 	{
		eop=1;
		breakflag=1;
		goto q008;
	}

	else if (reset==1&&! (scan==1) )
 	{
		eop=1;
		breakflag=1;
		goto q008;
	}

	else if (! (reset==1) &&scan==1)
 	{
		breakflag=1;
		goto q008;
	}

	else
 	{
		goto q008;
	}
  q012:

	if (eop==0)
 	{
		flag=wh;
		actnum=0;
		white=0;
		black=0;
		eoc=0;
		breakflag=0;
		goto q013;
	}

	else
 	{
		goto q007;
	}
  q013:

	if (black!=255&&breakflag==0)
 	{
		goto q014;
	}

	else if (white!=255)
 	{
		goto q014;
	}

	else if (! (black!=255) &&breakflag==0)
 	{
		goto q026;
	}

	else
 	{
		goto q026;
	}
  q014:

	if (video==wh)
 	{
		goto q015;
	}

	else
 	{
		goto q021;
	}
  q015:

	if (clk!=1)
 	{
		goto q015;
	}

	else
 	{
		eop=0;
		goto q016;
	}
  q016:

	if (reset==1&&flag==bl)
 	{
		eop=1;
		breakflag=1;
		white=white+1;
		actnum=actnum+1;
		memw=0;
		goto q019;
	}

	else if (reset==1&&! (flag==bl) )
 	{
		eop=1;
		breakflag=1;
		white=white+1;
		memw=1;
		goto q019;
	}

	else if (! (reset==1) &&flag==bl)
 	{
		white=white+1;
		actnum=actnum+1;
		memw=0;
		goto q019;
	}

	else
 	{
		white=white+1;
		memw=1;
		goto q019;
	}
  q019:

	if (eop==0)
 	{
		black=0;
		flag=wh;
		data=white;
		addr=actnum;
		goto q013;
	}

	else
 	{
		black=0;
		flag=wh;
		data=white;
		goto q013;
	}
  q021:

	if (clk!=1)
 	{
		goto q021;
	}

	else
 	{
		eop=0;
		goto q022;
	}
  q022:

	if (reset==1&&flag==wh)
 	{
		eop=1;
		breakflag=1;
		black=black+1;
		actnum=actnum+1;
		memw=0;
		goto q025;
	}

	else if (reset==1&&! (flag==wh) )
 	{
		eop=1;
		breakflag=1;
		black=black+1;
		memw=1;
		goto q025;
	}

	else if (! (reset==1) &&flag==wh)
 	{
		black=black+1;
		actnum=actnum+1;
		memw=0;
		goto q025;
	}

	else
 	{
		black=black+1;
		memw=1;
		goto q025;
	}
  q025:

	if (eop==0)
 	{
		flag=bl;
		white=0;
		data=black;
		addr=actnum;
		goto q013;
	}

	else
 	{
		flag=bl;
		white=0;
		data=black;
		goto q013;
	}
  q026:

	if (eop==0)
 	{
		memw=0;
		eoc=1;
		breakflag=0;
		goto q027;
	}

	else
 	{
		goto q007;
	}
  q027:

	if (start!=0&&breakflag==0)
 	{
		goto q028;
	}

	else
 	{
		goto q007;
	}
  q028:

	if (clk!=1)
 	{
		goto q028;
	}

	else
 	{
		eop=0;
		goto q029;
	}
  q029:

	if (reset==1&&start==0)
 	{
		eop=1;
		breakflag=1;
		goto q027;
	}

	else if (reset==1&&! (start==0) )
 	{
		eop=1;
		breakflag=1;
		goto q027;
	}

	else if (! (reset==1) &&start==0)
 	{
		breakflag=1;
		goto q027;
	}

	else
 	{
		goto q027;
	}
  q031:
	;
}
