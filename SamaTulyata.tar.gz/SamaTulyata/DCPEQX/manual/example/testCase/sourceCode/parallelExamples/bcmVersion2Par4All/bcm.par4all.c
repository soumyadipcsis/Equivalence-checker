#include <stdio.h>
int main()
{  int a,b,c,d,e,f,g,h,i,j,k,l,m;
   int h1, h2, h3, h4; 
     h1=b+c;
     h2=e+f;
     h3= b+f;
     h4=l+c; 

    # par begin 
       a=h1;
       d=h2;
       g=a+d;
     \PAR
       h=h3;
       k=h4;
       o=h+k;
    # par end
}
