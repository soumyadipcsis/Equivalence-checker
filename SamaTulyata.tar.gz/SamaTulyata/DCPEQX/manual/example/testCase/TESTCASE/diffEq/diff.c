
 Number of Places = 16
 
 Place : p1 
 Associated variable : a


 Place : p2 
 Associated variable : b


 Place : p3 
 Associated variable : c


 Place : p4 
 Associated variable : d


 Place : p5 
 Associated variable : e


 Place : p6 
 Associated variable : f


 Place : p7 
 Associated variable : g


 Place : p8 
 Associated variable : h


 Place : p9 
 Associated variable : i

 Place : p10 
 Associated variable : j


 Place : p11 
 Associated variable : k


 Place : p12
 Associated variable : l


 Place : p13
 Associated variable : m
 
 Place : p14
 Associated variable : n


 Place : p15
 Associated variable : o
 
 Place : p16
 Associated variable : p
 
 Number of Transitions = 15
 
 Transition : t1
 Transition function :a+1
 Guard conditions :n_g
 Printing Preset list(1) :p1 
 Printing Postset list(1) : p2


 Transition : t2
 Transition function :b+1
 Guard conditions :n_g
 Printing Preset list(1) :p2 
 Printing Postset list(1) : p3


 Transition : t3
 Transition function :c=a+b
 Guard conditions :c>=0
 Printing Preset list(1) :p3  
 Printing Postset list(1) : p4 


 Transition : t4
 Transition function :c+1
 Guard conditions :n_g
 Printing Preset list(1) :p4  
 Printing Postset list(1) : p5 


 Transition : t5
 Transition function :d=c
 Guard conditions :n_g
 Printing Preset list(1) :p5
 Printing Postset list(1) : p6


 Transition : t6
 Transition function :d+1
 Guard conditions :d>=0
 Printing Preset list(1) :p6
 Printing Postset list(1) : p7 


 Transition : t7
 Transition function :c+2
 Guard conditions :n_g
 Printing Preset list(1) :p7
 Printing Postset list(1) : p8 


 Transition : t8
 Transition function :c+3
 Guard conditions :n_g
 Printing Preset list(1) :p8
 Printing Postset list(1) : p9 

 Transition : t9
 Transition function :a+1
 Guard conditions :n_g
 Printing Preset list(1) :p9 
 Printing Postset list(1) : p10


 Transition : t10
 Transition function :b+1
 Guard conditions :n_g
 Printing Preset list(1) :p10 
 Printing Postset list(1) : p11


 Transition : t11
 Transition function :c=a+b
 Guard conditions :c>=0
 Printing Preset list(1) :p11  
 Printing Postset list(1) : p12 


 Transition : t12
 Transition function :c+1
 Guard conditions :n_g
 Printing Preset list(1) :p12  
 Printing Postset list(1) : p13 


 Transition : t13
 Transition function :d=c
 Guard conditions :n_g
 Printing Preset list(1) :p2
 Printing Postset list(1) : p14


 Transition : t14
 Transition function :d+1
 Guard conditions :d>=0
 Printing Preset list(1) :p14
 Printing Postset list(1) : p15 


 Transition : t15
 Transition function :c+2
 Guard conditions :n_g
 Printing Preset list(1) :p15
 Printing Postset list(1) : p16 


 Printing initial marking ... 
 Total number of initially marked places : 1
 Initially marked places are : p1 
