#!/bin/bash
 ./pres example/sequential/MODN/MODN_ORG.PRES example/sequential/MODN/MODN_TRANS.PRES > example/sequential/MODN/VerificationReport.txt

.
