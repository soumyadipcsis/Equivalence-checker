#include <stdio.h>

void main ()
{
    /* Soumyadip's Program. 
    int a, b, c, d;
    a = 5;
    if (a > 0)
        b = a;
    else
        c = a;
    
    d = b + c;*/
    
    
    
    
    /* Simple if-else
     * It adds an uncessary if-else which doesn't have any effect on 
     *    the program. NOT WORKING
    int a, b, c, d, e, f, g, h, k;
    scanf ("%d", &c);
    a = b = d = 0;
    if (c > 0)
        a = c + 10;
    else
        b = c - 10;
    
    if (d > 0)
        g = d;
    else
        h = d;
        
    d = a + b;
    
    printf ("%d", d);*/
    

    /* Simple if-else example: b is defined but not used. WORKING. 
    int a, b, c, d;
    scanf ("%d", &c);
    a = 0;
    b = 0;
    if (c > 0)
        a = c + 10;
    else
        a = c - 10;
    
    d = a + b;
    
    printf ("%d", d);*/


    /* Simple if-else example: No transition defines a variable which 
     *   is not used eventually. WORKING. 
    int a, b, c, d;
    scanf ("%d", &c);
    a = b = 0;
    if (c > 0)
        a = c + 10;
    else
        b = c - 10;
    
    d = a + b;
    
    printf ("%d", d);*/

    /* Simple while Loop example: Calculates Fibonacci. WORKING.
    int f1, f2, n, s, i;
    i = f1 = f2 = 1;
    scanf ("%d", &n);
    s = 0;
    while (i < n)
    {
        i++;
        s = f1 + f2;
        f1 = f2;
        f2 = s;
    }
    printf ("%d", s); */
    
    /* Simple For example: Sum of First n OR 9 natural numbers:  WORKING. * /
    int s, x, i, n;
    scanf ("%d", &n);
    s = x = 0;
    
    for (i = 0; i < n; i++)
    {
        x += i;
        s = x;
    }
    
    printf ("%d", s); */
    
    
}
