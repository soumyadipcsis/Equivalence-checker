#!/bin/bash
pushd DCPEQX/manual ; make clean; popd;
pushd SCPEQX/manual ; make clean ; popd;
pushd DCPEQX/manual ; make ; popd;
pushd SCPEQX/manual ; make ; popd;
pushd FSMDEQX/FSMDEQX-PE ; make ; popd;
pushd FSMDEQX/FSMDEQX-PE ; make ; popd;


