#include <stdio.h>

void main () {
    int m, n, i, k;
    scanf ("%d", &m);
    scanf ("%d", &n);
    k = 0;
    i = 0;
    while (i <= 10) {
        m = m + 10;
        n = n + 10;
        i++;
    }
    k = m + n;
    printf ("%d", k);
}
