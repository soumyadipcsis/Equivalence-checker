#!/bin/bash
./pres example/MODN/MODN_ORG.PRES example/MODN/MODN_TRANS.PRES > example/MODN/VerificationReport.txt
./pres example/SOD/SOD_ORG.PRES example/SOD/SOD_TRANS.PRES > example/SOD/VerificationReport.txt
./pres example/GCD/GCD_ORG.PRES example/GCD/GCD_TRANS.PRES > example/GCD/VerificationReport.txt
./pres example/LCM/LCM_ORG.PRES example/LCM/LCM_TRANS.PRES > example/LCM/VerificationReport.txt
./pres example/LRU/LRU_ORG.PRES example/LRU/LRU_TRANS.PRES > example/LRU/VerificationReport.txt
./pres example/LUP/LUP_OTG.PRES example/LUP/LUP_TRANS.PRES > example/LUP/VerificaTionReport.txt
./pres example/PERFECT/perfect_org.pres example/PERFECT/perfect_shd.pres > example/PERFECT/VerificaTionReport.txt

 
