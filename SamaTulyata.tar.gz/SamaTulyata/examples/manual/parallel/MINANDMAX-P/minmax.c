 int main() {
    int num, max, min, i, j, out;
    printf("Enter seven numbers:");
    scanf("%d", &num);
    max = min = num;
#pragma scop
    for (i = 0; i < 3; i++) {
        scanf("%d", &num);
        if (max < num)
            max = num;
    }
    for (j = 0; j < 3; j++)
    {
        scanf("%d", &num);

        if (min > num)
            min = num;
    }
#pragma endscop
    out = min + max;
    printf("%d ", out);
    return 0;
}
