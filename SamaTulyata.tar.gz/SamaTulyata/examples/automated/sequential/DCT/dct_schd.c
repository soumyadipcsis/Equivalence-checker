void main ()
{
	int a0;
	int i0;
	int i7;
	int a7;
	int b1;
	int i1;
	int i2;
	int a2;
	int a3;
	int i3;
	int i4;
	int a4;
	int b5;
	int i5;
	int i6;
	int a6;
	int b0;
	int c4;
	int d2;
	int b6;
	int d3;
	int c7;
	int c5;
	int d0;
	int d1;
	int c6;
	int d5;
	int d7;
	int sT0;
	int sT1;
	int d4;
	int d6;
	int o4;
	int o0;
	int sT2;
	int o2;
	int o6;
	int o1;
	int o7;
	int o3;
	int o5;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
  q10:
		a0=i0+i7;
		a7=i0-i7;
		goto q11;
  q11:
		b1=i1+i2;
		a2=i1-i2;
		a3=i3+i4;
		a4=i3-i4;
		goto q12;
  q12:
		b5=i5+i6;
		a6=i5-i6;
		goto q13;
  q13:
		b0=a0+a4;
		c4=a0-a4;
		d2=a2+a6;
		b6=a2-a6;
		goto q14;
  q14:
		d3=a3+a7;
		c7=a3-a7;
		c5=b5*678;
		goto q15;
  q15:
		d0=b0+b1;
		d1=b0-b1;
		c6=b6*678;
		goto q16;
  q16:
		d5=c5+c7;
		d7=c5-c7;
		sT0=d2*4;
		goto q17;
  q17:
		sT1=d3*4;
		sT0=d2*5;
		sT1=d3*5;
		goto q18;
  q18:
		d4=c4+c6;
		d6=c4-c6;
		o4=d0*678;
		o0=d1*678;
		goto q19;
  q19:
		sT2=sT0+sT1;
		sT1=d5*4;
		sT1=d5*5;
		sT1=d7*4;
		sT1=d7*5;
		goto q20;
  q20:
		o2=sT2;
		o6=sT2;
		sT0=d4*5;
		sT0=d4*4;
		goto q21;
  q21:
		sT0=d6*5;
		sT0=d6*4;
		goto q22;
  q22:
		sT2=sT0+sT1;
		sT2=sT0-sT1;
		sT2=sT0+sT1;
		goto q23;
  q23:
		sT2=sT0-sT1;
		goto q24;
  q24:
		o1=sT2;
		o7=sT2;
		o3=sT2;
		o5=sT2;
		goto q25;
  q25:
	;
}
