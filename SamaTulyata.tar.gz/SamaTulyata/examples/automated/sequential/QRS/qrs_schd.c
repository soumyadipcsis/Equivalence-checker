void main ()
{
	int y0m1;
	int y0m2;
	int ymax;
	int xmax;
	int zmax;
	int RR;
	int lymax;
	int lzmax;
	int lxmax;
	int fl1;
	int fl2;
	int fl3;
	int count;
	int ftm1;
	int data;
	int ecgm1;
	int indx;
	int i;
	int sT65_66;
	int sT4_66;
	int sT2_66;
	int ft;
	int ysi;
	int ftm2;
	int sT11_86;
	int sT12_86;
	int sT13_86;
	int sT10_86;
	int y0;
	int ath;
	int ys;
	int sT67_86;
	int sT15_86;
	int sT16_86;
	int sT17_86;
	int sT14_86;
	int sth2;
	int sT46_131;
	int sT68_110;
	int sT69_110;
	int sth1;
	int sT49_131;
	int sT70_110;
	int sT22_108;
	int sT47_131;
	int sT71_110;
	int sT72_110;
	int low;
	int sT76_128;
	int sT43_127;
	int high;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  q10:
		y0m1=0;
		y0m2=0;
		ymax=0;
		xmax=0;
		zmax=0;
		RR=0;
		lymax=0;
		lzmax=0;
		lxmax=0;
		fl1=0;
		fl2=0;
		fl3=0;
		count=0;
		ftm1=data;
		ecgm1=data;
		indx=data;
		i=1;
		goto q11;
  q11:

	if (i<=indx)
 	{
		sT65_66=data-ecgm1;
		goto q12;
	}

	else
 	{
		goto q21;
	}
  q12:
		sT4_66=ftm1+sT65_66;
		goto q13;
  q13:
		sT2_66=sT65_66/256;
		i=i+1;
		ft=ftm1;
		goto q14;
  q14:
		ysi=ft-ftm2;
		goto q15;
  q15:

	if (ysi>ymax)
 	{
		ymax=ysi;
		sT11_86=ysi/8;
		sT12_86=ysi/2;
		goto q16;
	}

	else
 	{
		sT11_86=ysi/8;
		sT12_86=ysi/2;
		goto q16;
	}
  q16:

	if (ft>xmax)
 	{
		xmax=ft;
		sT13_86=sT12_86+sT11_86;
		sT10_86=ymax/16;
		goto q17;
	}

	else
 	{
		sT13_86=sT12_86+sT11_86;
		sT10_86=ymax/16;
		goto q17;
	}
  q17:

	if (ft>0)
 	{
		y0=ft;
		ath=xmax/4;
		goto q18;
	}

	else
 	{
		ath=xmax/4;
		goto q18;
	}
  q18:

	if (ath>y0)
 	{
		y0=ath;
		ys=ath-y0m2;
		sT67_86=y0;
		goto q19;
	}

	else
 	{
		ys=y0-y0m2;
		sT67_86=y0;
		goto q19;
	}
  q19:

	if (ys>zmax)
 	{
		zmax=ys;
		sT15_86=ys/8;
		sT16_86=ys/2;
		goto q20;
	}

	else
 	{
		sT15_86=zmax/8;
		sT16_86=zmax/2;
		goto q20;
	}
  q20:
		ftm2=ftm1;
		ftm1=ft;
		y0m2=y0m1;
		y0m1=y0;
		sT17_86=sT16_86+sT15_86;
		sT14_86=zmax/16;
		sth2=sT17_86+sT14_86;
		ecgm1=data;
		goto q21;
  q21:
		sT46_131=data-ecgm1;
		sT68_110=xmax/4;
		sT69_110=xmax/2;
		goto q22;
  q22:

	if (ysi>sth1)
 	{
		fl1=0;
		count=0;
		sT49_131=ftm1+sT46_131;
		sT70_110=sT69_110+sT68_110;
		sT22_108=1;
		sT47_131=sT46_131/256;
		sT71_110=xmax/8;
		goto q23;
	}

	else
 	{
		sT49_131=ftm1+sT46_131;
		sT70_110=sT69_110+sT68_110;
		sT47_131=sT46_131/256;
		sT71_110=xmax/8;
		goto q23;
	}
  q23:

	if (ys>sth2)
 	{
		fl2=0;
		count=0;
		sT72_110=sT70_110+sT71_110;
		goto q24;
	}

	else
 	{
		sT72_110=sT70_110+sT71_110;
		goto q24;
	}
  q24:

	if (fl1==1&&fl2==1&&RR>low)
 	{
		RR=0;
		count=0;
		fl1=0;
		fl2=0;
		fl3=0;
		lxmax=0;
		lymax=0;
		lzmax=0;
		sT76_128=1;
		sT43_127=0;
		goto q25;
	}

	else
 	{
		sT76_128=count+1;
		goto q25;
	}
  q25:

	if (fl1==1||fl2==1)
 	{
		count=count+1;
		ysi=ft-ftm2;
		goto q26;
	}

	else
 	{
		ysi=ft-ftm2;
		goto q26;
	}
  q26:

	if (ysi>lymax)
 	{
		lymax=ysi;
		goto q27;
	}

	else
 	{
		goto q27;
	}
  q27:

	if (ft>lxmax)
 	{
		lxmax=ft;
		goto q28;
	}

	else
 	{
		goto q28;
	}
  q28:

	if (ft>0)
 	{
		y0=ft;
		ath=xmax/4;
		goto q29;
	}

	else
 	{
		ath=xmax/4;
		goto q29;
	}
  q29:

	if (y0<ath)
 	{
		y0=ath;
		ys=ath-y0m2;
		goto q30;
	}

	else
 	{
		ys=y0-y0m2;
		goto q30;
	}
  q30:

	if (ys>lzmax)
 	{
		lzmax=ys;
		goto q31;
	}

	else
 	{
		goto q31;
	}
  q31:

	if (count==8)
 	{
		fl1=0;
		fl2=0;
		count=0;
		goto q32;
	}

	else
 	{
		goto q32;
	}
  q32:

	if (RR>high)
 	{
		fl3=fl3+1;
		RR=0;
		ymax=ymax/2;
		zmax=zmax/2;
		goto q33;
	}

	else
 	{
		goto q33;
	}
  q33:
	;
}
