#include <stdio.h>

void main () {
    int a, b;
    scanf ("%d", &a);
    if (a > 10)
        a = 0;
    else 
        a =  1;
    a = a + 3;
    scanf ("%d", &b);
    printf ("%d", a);
    a = a + b;
    b = b + 10;
    printf ("%d", a);
    printf ("%d", b);
}