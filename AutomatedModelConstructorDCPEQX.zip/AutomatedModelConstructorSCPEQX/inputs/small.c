
//;; Function main (main)

main ()
{
  int d;
  int c;
  int b;
  int a;
  

2:     //<bb 2>:
  c = 0;
  a = 5;
  if (a > 0)
    goto <bb 3>;
  else
    goto <bb 4>;

<bb 3>:
  b = a;
  goto <bb 5>;

<bb 4>:
  c = a;

<bb 5>:
  d = b + c;
  printf ("%d",d);
  return;

}


