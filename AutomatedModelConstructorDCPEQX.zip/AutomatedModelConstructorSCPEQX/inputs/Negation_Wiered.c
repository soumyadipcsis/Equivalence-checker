#include <stdio.h>

void main ()
{
    int a, b, c, d;
    a = -10;
    a = -10 + b;
    a = 10 + -b;
    a = b + -c;
    a = -c + b;
    b = -c * d;
    c = -d;
    d = -d / c;
    if (a)
        a = a + b;
    else
        c = c - d;
    
}