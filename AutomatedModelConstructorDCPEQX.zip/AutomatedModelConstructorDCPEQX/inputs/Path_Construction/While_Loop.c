#include <stdio.h>

void main ()
{
    /* Simple while Loop example: Calculates Fibonacci. 
     * Path Constructor:
     *    WORKING. No extra output places constructed.
     * */
    int f1, f2, n, s, i;
    i = f1 = f2 = 1;
    scanf ("%d", &n);
    s = 0;
    while (i < n)
    {
        i++;
        s = f1 + f2;
        f1 = f2;
        f2 = s;
    }
    printf ("%d", s); 
    
}
