void main ()
{
	int a0;
	int a1;
	int a2;
	int h1;
	int h2;
	int h3;
	int h4;
	int h5;
	int h6;
	int h7;
	int h8;
	int h9;
	int s;
	int s1;
	int s2;
	int cv;
	int dp;
	int d;
	int i;
	int j;
	int k;
	int v;
	int p;
	int dv;
	int bv;
	int eop;
	int clk;
	int a0_in;
	int a1_in;
	int a2_in;
	int p339_in;
	int temp3;
	int p340_in;
	int TWO_RAISED_56;
	int host_out;
	int reset;
	int mult_fact;
	int temp;
	int temp1;
	int temp4;
	int temp2;
	int temp5;
	int temp6;
	int p_in;
	int temp7;
	int temp8;
	int v_in;
	int temp9;
	int temp10;
	int dv_in;
	int temp11;
	int temp12;
	int mult_fact1;
	int temp17;
	int temp13;
	int temp14;
	int temp15;
	int temp16;
	int temp18;
	int temp19;
	int temp20;
	int temp21;
	int temp22;
	int temp23;
	int temp31;
	int temp24;
	int temp25;
	int temp26;
	int temp27;
	int temp28;
	int temp29;
	int temp30;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
  q000:
		a0=0;
		a1=0;
		a2=0;
		h1=0;
		h2=0;
		h3=0;
		h4=0;
		h5=0;
		h6=0;
		h7=0;
		h8=0;
		h9=0;
		s=0;
		s1=0;
		s2=0;
		cv=0;
		dp=0;
		d=0;
		i=0;
		j=0;
		k=0;
		v=0;
		p=0;
		dv=0;
		bv=0;
		eop=0;
		goto q001;
  q001:

	if (eop==0)
 	{
		goto q002;
	}

	else
 	{
		goto q061;
	}
  q002:

	if (clk!=1)
 	{
		goto q002;
	}

	else
 	{
		a0=a0_in;
		a1=a1_in;
		a2=a2_in;
		p=p339_in*256;
		s=0;
		goto q003;
	}
  q003:
		temp3=p340_in*TWO_RAISED_56;
		goto q004;
  q004:
		p=p/256;
		goto q005;
  q005:
		p=p+temp3;
		cv=0;
		h7=0;
		h6=0;
		h4=0;
		dp=0;
		host_out=0;
		i=0;
		eop=0;
		goto q006;
  q006:

	if (i<=6&&eop==0)
 	{
		goto q008;
	}

	else
 	{
		goto q023;
	}
  q008:

	if (reset==1)
 	{
		eop=1;
		goto q009;
	}

	else
 	{
		goto q009;
	}
  q009:

	if (eop==1)
 	{
		mult_fact=1;
		temp=0;
		goto q010;
	}

	else
 	{
		i=i+1;
		goto q006;
	}
  q010:

	if (temp<=i)
 	{
		mult_fact=mult_fact*256;
		temp=temp+1;
		goto q010;
	}

	else
 	{
		temp1=p%mult_fact;
		temp4=mult_fact*256;
		goto q011;
	}
  q011:
		temp2=p/temp4;
		goto q012;
  q012:
		temp5=temp2*temp4;
		temp6=p_in*mult_fact;
		goto q013;
  q013:
		p=temp5+temp6;
		goto q014;
  q014:
		p=p+temp1;
		goto q015;
  q015:
		temp1=v%mult_fact;
		temp2=v/temp4;
		goto q016;
  q016:
		temp7=temp2*temp4;
		temp8=v_in*mult_fact;
		goto q017;
  q017:
		v=temp7+temp8;
		goto q018;
  q018:
		v=v+temp1;
		goto q019;
  q019:
		temp1=dv%mult_fact;
		temp2=dv/temp4;
		goto q020;
  q020:
		temp9=temp2*temp4;
		temp10=dv_in*mult_fact;
		goto q021;
  q021:
		dv=temp9+temp10;
		goto q022;
  q022:
		dv=dv+temp1;
		goto q006;
  q023:

	if (eop==0)
 	{
		eop=0;
		i=1;
		goto q024;
	}

	else
 	{
		goto q001;
	}
  q024:

	if (i<=6&&eop==0)
 	{
		goto q026;
	}

	else
 	{
		goto q001;
	}
  q026:

	if (reset==1)
 	{
		eop=1;
		goto q027;
	}

	else
 	{
		goto q027;
	}
  q027:

	if (eop==0)
 	{
		j=i+1;
		k=i-1;
		mult_fact=1;
		temp=0;
		goto q028;
	}

	else
 	{
		i=i+1;
		goto q024;
	}
  q028:

	if (temp<=j)
 	{
		mult_fact=mult_fact*256;
		temp=temp+1;
		goto q028;
	}

	else
 	{
		temp1=p%mult_fact;
		temp11=mult_fact*256;
		temp12=p_in*mult_fact;
		goto q029;
	}
  q029:
		temp2=p/temp11;
		goto q030;
  q030:
		p=temp2*temp11;
		goto q031;
  q031:
		p=p+temp12;
		goto q032;
  q032:
		p=p+temp1;
		mult_fact1=1;
		temp=0;
		goto q033;
  q033:

	if (temp<=k)
 	{
		mult_fact1=mult_fact1*256;
		temp=temp+1;
		goto q033;
	}

	else
 	{
		temp17=mult_fact1*256;
		temp13=mult_fact*256;
		goto q034;
	}
  q034:
		temp14=p%temp13;
		temp15=p%temp17;
		goto q035;
  q035:
		temp16=temp15/mult_fact1;
		temp18=temp14/mult_fact;
		goto q036;
  q036:
		d=temp18-temp16;
		goto q037;
  q037:
		dp=d/2;
		mult_fact=1;
		temp=0;
		goto q038;
  q038:

	if (temp<=i)
 	{
		mult_fact=mult_fact*256;
		temp=temp+1;
		goto q038;
	}

	else
 	{
		temp19=mult_fact*256;
		goto q039;
	}
  q039:
		temp20=v%temp19;
		goto q040;
  q040:
		temp21=a0_in*temp20;
		goto q041;
  q041:
		h1=temp21/mult_fact;
		goto q042;
  q042:
		h2=h1/16;
		goto q043;
  q043:
		h3=a1+h2;
		goto q044;
  q044:
		temp22=p%temp19;
		s2=dp*temp20;
		goto q045;
  q045:
		temp23=temp22*h3;
		temp31=temp22/mult_fact;
		goto q046;
  q046:
		h4=temp23/mult_fact;
		goto q047;
  q047:
		h5=h4/4;
		goto q048;
  q048:
		cv=h5+a2;
		temp24=dv%temp19;
		goto q049;
  q049:
		temp25=temp31/temp24;
		s2=s2/mult_fact;
		goto q050;
  q050:
		s1=temp25/mult_fact;
		h7=s2/4;
		goto q051;
  q051:
		h6=s1/4;
		goto q052;
  q052:
		s=h6+h7;
		goto q053;
  q053:
		h8=s*cv;
		goto q054;
  q054:
		h9=h8/2;
		temp1=bv%mult_fact;
		temp2=bv/temp19;
		goto q055;
  q055:
		temp26=temp2*temp19;
		temp27=h9+h6;
		goto q056;
  q056:
		temp28=temp27*mult_fact;
		goto q057;
  q057:
		temp29=temp26+temp28;
		goto q058;
  q058:
		bv=temp29+temp1;
		goto q059;
  q059:
		temp30=bv%temp19;
		goto q060;
  q060:
		host_out=temp30/mult_fact;
		goto q024;
  q061:
	;
}
